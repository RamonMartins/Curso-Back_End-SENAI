from django.contrib import admin
from .models import Configuracao

# Register your models here.
admin.site.register(Configuracao)